package com.example.homefinance

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class Cur(val code: String, val label: String, val symbol: String) {
    YER("YER", "ريال يمني", "ر.ي"),
    SAR("SAR", "ريال سعودي", "ر.س");

    companion object {
        fun from(code: String): Cur = values().firstOrNull { it.code == code } ?: YER
    }
}

val MONTHS = listOf(
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
)

val expenseCategories = listOf(
    "طعام وشراب", "فواتير", "إيجار", "مواصلات", "تعليم",
    "صحة", "ملابس", "ترفيه", "هدايا", "أخرى"
)

val incomeCategories = listOf("راتب", "عمل حر", "تجارة", "هدية", "أخرى")

/** Accepts Arabic-Indic digits and Arabic decimal separator. */
fun parseAmount(s: String): Double? {
    val sb = StringBuilder()
    for (ch in s.trim()) {
        if (ch in '٠'..'٩') {
            sb.append('0' + (ch - '٠'))
        } else if (ch in '۰'..'۹') {
            sb.append('0' + (ch - '۰'))
        } else if (ch == '٫') {
            sb.append('.')
        } else if (ch == ',' || ch == '٬' || ch == ' ') {
            // ignore thousands separators
        } else {
            sb.append(ch)
        }
    }
    return sb.toString().toDoubleOrNull()
}

fun fmtNum(a: Double): String =
    if (a % 1.0 == 0.0) String.format(Locale.US, "%,.0f", a)
    else String.format(Locale.US, "%,.2f", a)

fun money(a: Double, c: Cur): String = "${fmtNum(a)} ${c.symbol}"

fun fmtDate(ms: Long): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

/** Start (inclusive) and end (exclusive) of a month in local time. */
fun monthRange(year: Int, month: Int): Pair<Long, Long> {
    val c = Calendar.getInstance()
    c.clear()
    c.set(year, month, 1, 0, 0, 0)
    val start = c.timeInMillis
    c.add(Calendar.MONTH, 1)
    return start to c.timeInMillis
}

fun localToUtcMidnight(ms: Long): Long {
    val l = Calendar.getInstance()
    l.timeInMillis = ms
    val u = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
    u.clear()
    u.set(l.get(Calendar.YEAR), l.get(Calendar.MONTH), l.get(Calendar.DAY_OF_MONTH))
    return u.timeInMillis
}

fun utcToLocalNoon(ms: Long): Long {
    val u = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
    u.timeInMillis = ms
    val l = Calendar.getInstance()
    l.clear()
    l.set(u.get(Calendar.YEAR), u.get(Calendar.MONTH), u.get(Calendar.DAY_OF_MONTH), 12, 0, 0)
    return l.timeInMillis
}

private fun csv(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""

fun buildCsv(tx: List<TransactionEntity>, debts: List<DebtEntity>): String {
    val sb = StringBuilder()
    sb.append("\uFEFF")
    sb.append("النوع,المبلغ,العملة,الفئة,ملاحظة,التاريخ\n")
    for (t in tx) {
        val row = listOf(
            if (t.type == "INCOME") "دخل" else "مصروف",
            fmtNum(t.amount), t.currency, t.category, t.note, fmtDate(t.date)
        )
        sb.append(row.joinToString(",") { csv(it) }).append("\n")
    }
    sb.append("\n")
    sb.append("الشخص,الاتجاه,المبلغ,المسدد,المتبقي,العملة,الاستحقاق,ملاحظة\n")
    for (d in debts) {
        val row = listOf(
            d.person,
            if (d.direction == "OWED_BY_ME") "عليّ" else "لي",
            fmtNum(d.amount), fmtNum(d.paid), fmtNum(d.amount - d.paid),
            d.currency, d.dueDate?.let { fmtDate(it) } ?: "", d.note
        )
        sb.append(row.joinToString(",") { csv(it) }).append("\n")
    }
    return sb.toString()
}
