package com.example.homefinance

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FinanceViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val transactions: StateFlow<List<TransactionEntity>> =
        dao.observeTransactions()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val debts: StateFlow<List<DebtEntity>> =
        dao.observeDebts()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTransaction(t: TransactionEntity) {
        viewModelScope.launch { dao.insertTransaction(t) }
    }

    fun deleteTransaction(t: TransactionEntity) {
        viewModelScope.launch { dao.deleteTransaction(t) }
    }

    fun addDebt(d: DebtEntity) {
        viewModelScope.launch { dao.insertDebt(d) }
    }

    fun updateDebt(d: DebtEntity) {
        viewModelScope.launch { dao.updateDebt(d) }
    }

    fun deleteDebt(d: DebtEntity) {
        viewModelScope.launch { dao.deleteDebt(d) }
    }
}
