package com.example.homefinance

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Calendar

private val GREEN = Color(0xFF2E7D32)
private val RED = Color(0xFFC62828)

// ---------------------------------------------------------------- App shell

@Composable
fun FinanceApp(vm: FinanceViewModel = viewModel()) {
    val tx by vm.transactions.collectAsState()
    val debts by vm.debts.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var cur by remember { mutableStateOf(Cur.YER) }
    var showAddTx by remember { mutableStateOf(false) }
    var showAddDebt by remember { mutableStateOf(false) }

    val items = listOf(
        "الرئيسية" to Icons.Default.Home,
        "العمليات" to Icons.Default.DateRange,
        "الديون" to Icons.Default.Person,
        "المزيد" to Icons.Default.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab in 0..2) {
                FloatingActionButton(onClick = {
                    if (tab == 2) showAddDebt = true else showAddTx = true
                }) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة")
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (tab != 3) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    CurrencyChips(cur) { cur = it }
                }
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> SummaryScreen(tx, debts, cur)
                    1 -> TransactionsScreen(tx, cur) { vm.deleteTransaction(it) }
                    2 -> DebtsScreen(
                        debts, cur,
                        onUpdate = { vm.updateDebt(it) },
                        onDelete = { vm.deleteDebt(it) }
                    )
                    else -> MoreScreen(tx, debts)
                }
            }
        }
    }

    if (showAddTx) {
        AddTransactionDialog(
            defaultCur = cur,
            onDismiss = { showAddTx = false },
            onSave = { vm.addTransaction(it); showAddTx = false }
        )
    }
    if (showAddDebt) {
        AddDebtDialog(
            defaultCur = cur,
            onDismiss = { showAddDebt = false },
            onSave = { vm.addDebt(it); showAddDebt = false }
        )
    }
}

@Composable
fun CurrencyChips(selected: Cur, onSelect: (Cur) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Cur.values().forEach { c ->
            FilterChip(
                selected = selected == c,
                onClick = { onSelect(c) },
                label = { Text(c.label) }
            )
        }
    }
}

// ---------------------------------------------------------------- Summary

@Composable
fun SummaryScreen(tx: List<TransactionEntity>, debts: List<DebtEntity>, cur: Cur) {
    val now = remember { Calendar.getInstance() }
    var year by remember { mutableIntStateOf(now.get(Calendar.YEAR)) }
    var month by remember { mutableIntStateOf(now.get(Calendar.MONTH)) }

    val range = monthRange(year, month)
    val all = tx.filter { it.currency == cur.code }
    val monthTx = all.filter { it.date >= range.first && it.date < range.second }
    val income = monthTx.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expense = monthTx.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val totalBalance = all.filter { it.type == "INCOME" }.sumOf { it.amount } -
            all.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val cats = monthTx.filter { it.type == "EXPENSE" }
        .groupBy { it.category }
        .map { (k, v) -> k to v.sumOf { it.amount } }
        .sortedByDescending { it.second }

    val myDebt = debts.filter { it.currency == cur.code && it.direction == "OWED_BY_ME" }
        .sumOf { it.amount - it.paid }
    val theirDebt = debts.filter { it.currency == cur.code && it.direction == "OWED_TO_ME" }
        .sumOf { it.amount - it.paid }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = {
                    if (month == 0) { month = 11; year -= 1 } else month -= 1
                }) { Text("السابق") }
                Text("${MONTHS[month]} $year", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                TextButton(onClick = {
                    if (month == 11) { month = 0; year += 1 } else month += 1
                }) { Text("التالي") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ملخص الشهر", fontWeight = FontWeight.Bold)
                    StatRow("الدخل", money(income, cur), GREEN)
                    StatRow("المصروف", money(expense, cur), RED)
                    StatRow(
                        "المتبقي هذا الشهر", money(income - expense, cur),
                        if (income - expense >= 0) GREEN else RED
                    )
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الوضع العام", fontWeight = FontWeight.Bold)
                    StatRow(
                        "الرصيد الكلي (كل الأشهر)", money(totalBalance, cur),
                        if (totalBalance >= 0) GREEN else RED
                    )
                    StatRow("ديون عليّ (المتبقي)", money(myDebt, cur), RED)
                    StatRow("ديون لي (المتبقي)", money(theirDebt, cur), GREEN)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("المصروف حسب الفئة", fontWeight = FontWeight.Bold)
                    if (cats.isEmpty()) {
                        Text("لا توجد مصروفات في هذا الشهر")
                    }
                    cats.forEach { (name, sum) ->
                        Column {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name)
                                Text(money(sum, cur))
                            }
                            LinearProgressIndicator(
                                progress = { (sum / expense).toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, color = color, fontWeight = FontWeight.Bold)
    }
}

// ---------------------------------------------------------------- Transactions

@Composable
fun TransactionsScreen(
    tx: List<TransactionEntity>,
    cur: Cur,
    onDelete: (TransactionEntity) -> Unit
) {
    val list = tx.filter { it.currency == cur.code }
    var toDelete by remember { mutableStateOf<TransactionEntity?>(null) }

    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا توجد عمليات بعد. اضغط + لإضافة أول عملية")
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { t ->
                val income = t.type == "INCOME"
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(t.category, fontWeight = FontWeight.Bold)
                            if (t.note.isNotBlank()) Text(t.note, fontSize = 13.sp)
                            Text(fmtDate(t.date), fontSize = 12.sp)
                        }
                        Text(
                            (if (income) "+" else "-") + money(t.amount, cur),
                            color = if (income) GREEN else RED,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { toDelete = t }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف")
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { t ->
        ConfirmDialog(
            text = "حذف هذه العملية؟",
            onConfirm = { onDelete(t); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
}

// ---------------------------------------------------------------- Debts

@Composable
fun DebtsScreen(
    debts: List<DebtEntity>,
    cur: Cur,
    onUpdate: (DebtEntity) -> Unit,
    onDelete: (DebtEntity) -> Unit
) {
    val list = debts.filter { it.currency == cur.code }
    var toDelete by remember { mutableStateOf<DebtEntity?>(null) }
    var toPay by remember { mutableStateOf<DebtEntity?>(null) }

    val myDebt = list.filter { it.direction == "OWED_BY_ME" }.sumOf { it.amount - it.paid }
    val theirDebt = list.filter { it.direction == "OWED_TO_ME" }.sumOf { it.amount - it.paid }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatRow("إجمالي ما عليّ", money(myDebt, cur), RED)
                    StatRow("إجمالي ما لي", money(theirDebt, cur), GREEN)
                }
            }
        }
        if (list.isEmpty()) {
            item { Text("لا توجد ديون مسجلة بهذه العملة") }
        }
        items(list, key = { it.id }) { d ->
            DebtCard(d, onPay = { toPay = d }, onDelete = { toDelete = d })
        }
    }

    toDelete?.let { d ->
        ConfirmDialog(
            text = "حذف دين ${d.person}؟",
            onConfirm = { onDelete(d); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
    toPay?.let { d ->
        PaymentDialog(
            debt = d,
            onDismiss = { toPay = null },
            onPay = { x ->
                onUpdate(d.copy(paid = minOf(d.amount, d.paid + x)))
                toPay = null
            }
        )
    }
}

@Composable
fun DebtCard(d: DebtEntity, onPay: () -> Unit, onDelete: () -> Unit) {
    val cur = Cur.from(d.currency)
    val remaining = d.amount - d.paid
    val mine = d.direction == "OWED_BY_ME"
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(d.person, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(if (mine) "دين عليّ" else "دين لي", color = if (mine) RED else GREEN)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف")
                }
            }
            Text("المبلغ: ${money(d.amount, cur)}   |   المسدد: ${money(d.paid, cur)}")
            Text(
                if (remaining <= 0.0) "مسدّد بالكامل" else "المتبقي: ${money(remaining, cur)}",
                fontWeight = FontWeight.SemiBold
            )
            LinearProgressIndicator(
                progress = { (d.paid / d.amount).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )
            d.dueDate?.let { Text("الاستحقاق: ${fmtDate(it)}") }
            if (d.note.isNotBlank()) Text(d.note, fontSize = 13.sp)
            if (remaining > 0.0) {
                TextButton(onClick = onPay) { Text("إضافة دفعة") }
            }
        }
    }
}

// ---------------------------------------------------------------- More

@Composable
fun MoreScreen(tx: List<TransactionEntity>, debts: List<DebtEntity>) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("تصدير البيانات", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("يُنشئ ملف CSV يمكن فتحه في Excel، ويمكنك إرساله أو حفظه عبر أي تطبيق.")
        Button(onClick = {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "بيانات مصروفي")
                putExtra(Intent.EXTRA_TEXT, buildCsv(tx, debts))
            }
            context.startActivity(Intent.createChooser(intent, "تصدير"))
        }) { Text("تصدير / مشاركة") }

        Text("عن التطبيق", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "مصروفي: تطبيق لتنظيم مالية المنزل. البيانات محفوظة على جهازك فقط. " +
                    "كل عملة (ريال يمني / ريال سعودي) تُحسب بشكل منفصل دون تحويل بينهما."
        )
    }
}

// ---------------------------------------------------------------- Dialogs

@Composable
fun ConfirmDialog(text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text("حذف") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerWrapper(initialMs: Long, onDismiss: () -> Unit, onPicked: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = localToUtcMidnight(initialMs))
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val sel = state.selectedDateMillis
                if (sel != null) onPicked(utcToLocalNoon(sel)) else onDismiss()
            }) { Text("تم") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    ) {
        DatePicker(state = state)
    }
}

@Composable
fun AddTransactionDialog(defaultCur: Cur, onDismiss: () -> Unit, onSave: (TransactionEntity) -> Unit) {
    var type by remember { mutableStateOf("EXPENSE") }
    var amount by remember { mutableStateOf("") }
    var cur by remember { mutableStateOf(defaultCur) }
    var category by remember { mutableStateOf(expenseCategories.first()) }
    var note by remember { mutableStateOf("") }
    var dateMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showPicker by remember { mutableStateOf(false) }
    val cats = if (type == "EXPENSE") expenseCategories else incomeCategories

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة عملية") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = type == "EXPENSE",
                        onClick = { type = "EXPENSE"; category = expenseCategories.first() },
                        label = { Text("مصروف") }
                    )
                    FilterChip(
                        selected = type == "INCOME",
                        onClick = { type = "INCOME"; category = incomeCategories.first() },
                        label = { Text("دخل") }
                    )
                }
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("المبلغ") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                CurrencyChips(cur) { cur = it }
                Text("الفئة")
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    cats.forEach { c ->
                        FilterChip(
                            selected = category == c,
                            onClick = { category = c },
                            label = { Text(c) }
                        )
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة (اختياري)") }
                )
                OutlinedButton(onClick = { showPicker = true }) {
                    Text("التاريخ: ${fmtDate(dateMs)}")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = parseAmount(amount)
                if (a != null && a > 0) {
                    onSave(
                        TransactionEntity(
                            type = type, amount = a, currency = cur.code,
                            category = category, note = note.trim(), date = dateMs
                        )
                    )
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )

    if (showPicker) {
        DatePickerWrapper(
            initialMs = dateMs,
            onDismiss = { showPicker = false },
            onPicked = { dateMs = it; showPicker = false }
        )
    }
}

@Composable
fun AddDebtDialog(defaultCur: Cur, onDismiss: () -> Unit, onSave: (DebtEntity) -> Unit) {
    var person by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("OWED_BY_ME") }
    var amount by remember { mutableStateOf("") }
    var cur by remember { mutableStateOf(defaultCur) }
    var note by remember { mutableStateOf("") }
    var dueMs by remember { mutableStateOf<Long?>(null) }
    var showPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة دين") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = direction == "OWED_BY_ME",
                        onClick = { direction = "OWED_BY_ME" },
                        label = { Text("دين عليّ") }
                    )
                    FilterChip(
                        selected = direction == "OWED_TO_ME",
                        onClick = { direction = "OWED_TO_ME" },
                        label = { Text("دين لي") }
                    )
                }
                OutlinedTextField(
                    value = person,
                    onValueChange = { person = it },
                    label = { Text("اسم الشخص") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("المبلغ") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                CurrencyChips(cur) { cur = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { showPicker = true }) {
                        Text(dueMs?.let { "الاستحقاق: ${fmtDate(it)}" } ?: "تاريخ الاستحقاق (اختياري)")
                    }
                    if (dueMs != null) {
                        TextButton(onClick = { dueMs = null }) { Text("مسح") }
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة (اختياري)") }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = parseAmount(amount)
                if (a != null && a > 0 && person.isNotBlank()) {
                    onSave(
                        DebtEntity(
                            person = person.trim(), direction = direction, amount = a,
                            currency = cur.code, dueDate = dueMs, note = note.trim()
                        )
                    )
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )

    if (showPicker) {
        DatePickerWrapper(
            initialMs = dueMs ?: System.currentTimeMillis(),
            onDismiss = { showPicker = false },
            onPicked = { dueMs = it; showPicker = false }
        )
    }
}

@Composable
fun PaymentDialog(debt: DebtEntity, onDismiss: () -> Unit, onPay: (Double) -> Unit) {
    var amount by remember { mutableStateOf("") }
    val cur = Cur.from(debt.currency)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("دفعة لـ ${debt.person}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المتبقي: ${money(debt.amount - debt.paid, cur)}")
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("مبلغ الدفعة") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = parseAmount(amount)
                if (a != null && a > 0) onPay(a)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
