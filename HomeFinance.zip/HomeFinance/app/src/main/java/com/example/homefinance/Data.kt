package com.example.homefinance

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,          // INCOME or EXPENSE
    val amount: Double,
    val currency: String,      // YER or SAR
    val category: String,
    val note: String,
    val date: Long
)

@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val person: String,
    val direction: String,     // OWED_BY_ME or OWED_TO_ME
    val amount: Double,
    val paid: Double = 0.0,
    val currency: String,
    val dueDate: Long? = null,
    val note: String = ""
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun observeTransactions(): Flow<List<TransactionEntity>>

    @Insert
    suspend fun insertTransaction(t: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(t: TransactionEntity)

    @Query("SELECT * FROM debts ORDER BY id DESC")
    fun observeDebts(): Flow<List<DebtEntity>>

    @Insert
    suspend fun insertDebt(d: DebtEntity)

    @Update
    suspend fun updateDebt(d: DebtEntity)

    @Delete
    suspend fun deleteDebt(d: DebtEntity)
}

@Database(entities = [TransactionEntity::class, DebtEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): FinanceDao

    companion object {
        @Volatile
        private var instance: AppDb? = null

        fun get(context: Context): AppDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDb::class.java,
                    "finance.db"
                ).build().also { instance = it }
            }
    }
}
